
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains

class TabNavigator:
    def __init__(self, driver, logger):
        self.driver = driver
        self.logger = logger

    def run(self):
        self.logger.info("\nSimulation de navigation réelle au clavier...")
        action = ActionChains(self.driver)
        elements_reached = []
        for _ in range(50):  # Limite à 50 tabulations
            action.send_keys(Keys.TAB).perform()
            active = self.driver.execute_script("return document.activeElement;")
            tag = active.tag_name
            text = active.text.strip() or active.get_attribute("alt") or active.get_attribute("title")
            href = active.get_attribute("href")
            elements_reached.append((tag, text, href))
            self.logger.info(f"Focus sur: {tag}, texte: {text}, href: {href}")
        return elements_reached
