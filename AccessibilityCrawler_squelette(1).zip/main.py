
from core.config import Config
from core.crawler import AccessibilityCrawler
from utils.log_utils import setup_logger

if __name__ == "__main__":
    logger = setup_logger()
    config = Config()
    crawler = AccessibilityCrawler(config)
    crawler.crawl()
    crawler.generate_report()
