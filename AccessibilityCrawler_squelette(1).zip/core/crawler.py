
from modules.contrast_checker import ContrastChecker
from modules.color_simulator import ColorSimulator
from modules.tab_navigator import TabNavigator

class AccessibilityCrawler:
    def __init__(self, config):
        self.config = config
        self.modules = []
        self._load_modules()

    def _load_modules(self):
        if 'contrast' in self.config.get_enabled_modules():
            self.modules.append(ContrastChecker())
        if 'daltonism' in self.config.get_enabled_modules():
            self.modules.append(ColorSimulator())
        if 'tab_navigation' in self.config.get_enabled_modules():
            self.modules.append(TabNavigator())

    def crawl(self):
        for module in self.modules:
            module.run()

    def generate_report(self):
        pass
