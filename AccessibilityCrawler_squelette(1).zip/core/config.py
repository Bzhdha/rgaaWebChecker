
class Config:
    def __init__(self):
        self.driver_path = None
        self.enabled_modules = ['contrast', 'daltonism', 'tab_navigation']
        self.report_format = 'markdown'

    def set_driver_path(self, path):
        self.driver_path = path

    def get_enabled_modules(self):
        return self.enabled_modules

    def get_report_format(self):
        return self.report_format
